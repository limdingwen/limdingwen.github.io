// Copyright 2023 Lim Ding Wen
//
// This file is part of Anything Also Cam.
//
// Anything Also Cam is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
//
// Anything Also Cam is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License along with Anything Also Cam. If not, see <https://www.gnu.org/licenses/>.

#[cfg(feature = "gui_gtk3")]
use crate::gui_gtk3::run_gui;
use crate::tcp_server::serve;
use crate::stream_decoder::decode;
use tokio::{
	task::{
		spawn_blocking,
		spawn
	},
	sync::{
		watch,
		mpsc
	},
	main
};
use simplelog::{
	LevelFilter::{
		Off,
		Error,
		Warn,
		Info,
		Debug,
		Trace
	},
	TerminalMode::Mixed,
	ColorChoice::Auto,
	Config,
	TermLogger
};
use std::env::args;

pub mod stream_decoder;
pub mod tcp_server;
#[cfg(feature = "gui_gtk3")]
pub mod gui_gtk3;

const TCP_STREAM_DECODER_CHANNEL_SIZE: usize = 32;
const BIND_ADDRESS: &str = "0.0.0.0";
const PORT: u16 = 4546;

#[cfg(not(any(feature = "gui_gtk3")))]
compile_error!("You need to enable exactly 1 GUI module, check COMPILE.md for the full list");

#[main]
async fn main() {
	// Create logger
	let mut filter = Info;
	let mut filter_checker = args();
	while let Some(arg) = filter_checker.next() {
		if arg.eq("--log") {
			match filter_checker.next() {
				Some(level) => filter = match level.as_str() {
					"off" => Off,
					"error" => Error,
					"warn" => Warn,
					"info" => Info,
					"debug" => Debug,
					"trace" => Trace,
					_ => {
						println!("--log off/error/warn/info/debug/trace");
						break
					}
				},
				None => {
					println!("--log off/error/warn/info/debug/trace");
					break
				}
			}
		}
	}
	if let Err(error) = TermLogger::init(filter, Config::default(), Mixed, Auto) {
		println!("ERROR: Unable to initialise logger due to {}, no logs will be produced", error);
	}
	
	// Create channels
	let (tcp_to_decoder_sender, tcp_to_decoder_receiver) = mpsc::channel(TCP_STREAM_DECODER_CHANNEL_SIZE);
	let (decoder_output_sender, decoder_output_receiver) = watch::channel(None);
	
	// Spawn modules
	spawn(serve(tcp_to_decoder_sender));
	spawn(decode(tcp_to_decoder_receiver, decoder_output_sender));
	let _ = spawn_blocking(|| run_gui(decoder_output_receiver)).await;
}
