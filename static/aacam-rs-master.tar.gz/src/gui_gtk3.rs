// Copyright 2023 Lim Ding Wen
//
// This file is part of Anything Also Cam.
//
// Anything Also Cam is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
//
// Anything Also Cam is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License along with Anything Also Cam. If not, see <https://www.gnu.org/licenses/>.

use gtk::prelude::*;
use gtk::{
	Application,
	ApplicationWindow,
	Label,
	Image,
	Box,
	Orientation::Vertical,
	glib::{
		timeout_add_local,
		Bytes,
		Continue
	}
};
use gtk::gdk_pixbuf::{
	Pixbuf,
	Colorspace
};
use local_ip_address::local_ip;
use qrcode_generator::{
	QrCodeEcc,
	to_image_buffer
};
use image::{
	ImageBuffer,
	Rgb
};
use std::{
	ops::Deref,
	time::Duration,
	iter::repeat
};
use tokio::sync::watch::Receiver;
use av_data::frame::{
	MediaKind::Video,
	Frame
};
use log::{
	trace,
	warn,
	error,
	info
};
use crate::{
	PORT
};

static mut DECODER_OUTPUT: Option<Receiver<Option<Frame>>> = None;

const BORDER_WIDTH: u32 = 10;
const LAYOUT_SPACING: i32 = 10;
const QR_IMAGE_SIZE: usize = 350;
const QR_IMAGE_BG: (u8, u8, u8) = (255, 255, 255);
const QR_IMAGE_FG: (u8, u8, u8) = (0, 0, 0);

// Taken from https://github.com/image-rs/image/blob/master/src/utils/mod.rs
#[inline(always)]
pub(crate) fn expand_packed<F>(buf: &mut [u8], channels: usize, bit_depth: u8, mut func: F)
where
    F: FnMut(u8, &mut [u8]),
{
    let pixels = buf.len() / channels * bit_depth as usize;
    let extra = pixels % 8;
    let entries = pixels / 8
        + match extra {
            0 => 0,
            _ => 1,
        };
    let mask = ((1u16 << bit_depth) - 1) as u8;
    let i = (0..entries)
        .rev() // Reverse iterator
        .flat_map(|idx|
            // This has to be reversed to
            (0..8/bit_depth).map(|i| i*bit_depth).zip(repeat(idx)))
        .skip(extra);
    let buf_len = buf.len();
    let j_inv = (channels..buf_len).step_by(channels);
    for ((shift, i), j_inv) in i.zip(j_inv) {
        let j = buf_len - j_inv;
        let pixel = (buf[i] & (mask << shift)) >> shift;
        func(pixel, &mut buf[j as usize..(j + channels) as usize])
    }
}

fn build_ui(application: &gtk::Application) {
	// Create window
	let window = ApplicationWindow::new(application);
    window.set_title("Anywhere Also Cam");
    window.set_border_width(BORDER_WIDTH);
    window.set_position(gtk::WindowPosition::Center);

	// Create vertical layout box for all GUI elements
	let layout = Box::new(Vertical, LAYOUT_SPACING);
	window.add(&layout);

	// Create IP label
	let ip = local_ip();
	let url = if let Ok(ip) = ip {
		Some(format!("aacam://{}:{}", ip, PORT))
	}
	else {
		None
	};
	let ip_text = if let Some(ref url) = url {
		format!("Step 1: Use the same wifi network.\nStep 2: Go to the web app.\nStep 3: Scan the QR code, or type in {}", url)
	}
	else {
		"Unable to get IP".to_owned()
	};
    let ip_label = Label::new(Some(&ip_text));
    layout.pack_start(&ip_label, false, false, 0);
    
    // Create QR code
    let qr_pixbuf;
    let qr_image = Image::from_pixbuf(if let Some(url) = url {
		// Generate QR greyscale image
		let qr = to_image_buffer(url, QrCodeEcc::Low, QR_IMAGE_SIZE);
		if let Ok(qr) = qr {
			// Convert greyscale to RGB (code taken from https://docs.rs/image/0.24.6/src/image/buffer.rs.html#1318-1345)
			let imagebuf_rgb = {
				let (width, height) = qr.dimensions();
				let mut data = qr.into_raw();
				let entries = data.len();
				data.resize(entries.checked_mul(3).unwrap(), 0);
				let mut buffer: ImageBuffer<Rgb<u8>, Vec<u8>> = ImageBuffer::from_vec(width, height, data).unwrap();
				expand_packed(&mut buffer, 3, 8, |idx, pixel| {
					let (r, g, b) = if idx == 0 {
						QR_IMAGE_FG
					}
					else {
						QR_IMAGE_BG
					};
					pixel[0] = r;
					pixel[1] = g;
					pixel[2] = b;
				});
				buffer
			};
			
			// Create GTK3-compatible pixel buffer
			let flatsample = imagebuf_rgb.into_flat_samples();
			qr_pixbuf = Pixbuf::from_bytes(&Bytes::from_owned(flatsample.samples), Colorspace::Rgb, false, 8, flatsample.layout.width.try_into().unwrap(), flatsample.layout.height.try_into().unwrap(), flatsample.layout.height_stride.try_into().unwrap());
			Some(&qr_pixbuf)
		}
		else {
			None
		}
	}
	else {
		None
	});
    layout.pack_start(&qr_image, false, false, 0);
    
    // Create streaming output
    let stream_image = Image::new();
    layout.pack_start(&stream_image, false, false, 0);

	// Finish creating window
    window.show_all();
    
    // Create stream updater
    timeout_add_local(Duration::from_millis(33), move || {
		'end: {
			unsafe {
				// Don't update if DECODER_OUTPUT has not been set
				let Some(ref mut decoder_output) = DECODER_OUTPUT else {
					warn!("Decoder output channel has not been passed to GUI GTK3");
					break 'end;
				};
				
				// Don't update if frame has not changed
				match decoder_output.has_changed() {
					Ok(has_changed) => if !has_changed {
						break 'end
					}
					Err(error) => {
						error!("Decoder output channel closed");
						break 'end
					}
				}
				
				// Get most recent, changed frame and put into image
				let borrowed_frame = decoder_output.borrow_and_update();
				let Some(frame) = borrowed_frame.deref() else {
					warn!("Unable to get frame from decoder output");
					break 'end;
				};
				let (width, height) = match &frame.kind {
					Video(info) => (info.width, info.height),
					_ => {
						warn!("Decoder outputted a non-video frame");
						break 'end
					}
				};
				let r_plane = match frame.buf.as_slice_inner(0) {
					Ok(x) => x,
					Err(error) => {
						warn!("Unable to get R plane");
						break 'end
					}
				};
				let g_plane = match frame.buf.as_slice_inner(1) {
					Ok(x) => x,
					Err(error) => {
						warn!("Unable to get R plane");
						break 'end
					}
				};
				let b_plane = match frame.buf.as_slice_inner(2) {
					Ok(x) => x,
					Err(error) => {
						warn!("Unable to get R plane");
						break 'end
					}
				};
				let mut buffer: Vec<u8> = Vec::<u8>::with_capacity(r_plane.len() * 3);
				let mut index = 0;
				for y in r_plane {
					buffer.push(*y);
					buffer.push(*y);
					buffer.push(*y);
				}
				//trace!("{:?} = {:?} * {:?} * 3, {:?}, {:?}, {:?}", buffer.len(), width, height, r_plane.len(), g_plane.len(), b_plane.len());
				let pixbuf = Pixbuf::from_bytes(&Bytes::from_owned(buffer), Colorspace::Rgb, false, 8, width.try_into().unwrap(), height.try_into().unwrap(), (width * 3).try_into().unwrap());
				stream_image.set_from_pixbuf(Some(&pixbuf));
			}
		}
		
		Continue(true)
	});
}

pub fn run_gui(decoder_output: Receiver<Option<Frame>>) {
	// Set global variable (HACKHACK)
	unsafe {
		DECODER_OUTPUT = Some(decoder_output);
	}
	
	// Create and run GTK3 application
    let application =
        Application::new(Some("me.limdingwen.anywhere-also-cam"), Default::default());
    application.connect_activate(build_ui);
    info!("Running GTK3 GUI...");
    application.run_with_args::<String>(Default::default());
}
