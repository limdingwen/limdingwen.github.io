// Copyright 2023 Lim Ding Wen
//
// This file is part of Anything Also Cam.
//
// Anything Also Cam is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
//
// Anything Also Cam is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License along with Anything Also Cam. If not, see <https://www.gnu.org/licenses/>.

use local_ip_address::local_ip;
use tokio::{
	net::TcpListener,
	spawn,
	select,
	sync::mpsc::Sender,
	sync::broadcast::channel
};
use tokio_tungstenite::{
	tungstenite::{
		error::Error::ConnectionClosed,
		protocol::Message::Text
	},
	accept_async
};
use futures_util::{
	SinkExt,
	StreamExt
};
use log::{
	trace,
	info,
	warn,
	error,
	debug
};
use base64::engine::{
	Engine,
	general_purpose::STANDARD
};
use std::{
	vec::Vec,
	cmp::min
};
use crate::{
	BIND_ADDRESS,
	PORT
};

const DISCONNECT_CHANNEL_SIZE: usize = 4;

pub async fn serve(decoder_sender: Sender<Vec<u8>>) {
	// Start WebSocket server
	trace!("Starting WebSocket server...");
    let listener = TcpListener::bind((BIND_ADDRESS, PORT)).await.expect("Cannot bind to address and port! Is it already in use?");
    info!("Serving on aacam://{}:{}", if let Ok(ip) = local_ip() {
		ip.to_string()
	}
	else {
		BIND_ADDRESS.to_owned()
	}, PORT);
	
	// Create disconnect channel
	let (disconnect_sender, _) = channel::<()>(DISCONNECT_CHANNEL_SIZE);
	
	'listen_loop: loop {
		// Listen to connections
		let (tcp_stream, address) = match listener.accept().await {
			Ok(x) => x,
			Err(error) => {
				error!("Unable to accept connection due to {}", error);
				continue 'listen_loop
			}
		};
		debug!("Incoming connection from {}", address);
		
		// Clone channels
		let disconnect_sender = disconnect_sender.clone();
		let mut disconnect_receiver = disconnect_sender.subscribe();
		let decoder_sender = decoder_sender.clone();
		
		spawn(async move {
			// Accept new connection
			let mut ws_stream = match accept_async(tcp_stream).await {
				Ok(x) => x,
				Err(error) => {
					error!("Unable to accept incoming due to {}", error);
					return
				}
			};
			info!("Accepted connection from {}", address);
			
			// Store if GOT_CAM/OK_CAM handshake is done before streaming starts
			let mut is_ready = false;
			
			// Message loop
			'message_loop: loop {
				select! {
					message = ws_stream.next() => {
						// Check if the stream has ended
						let message = match message {
							Some(x) => x,
							None => break 'message_loop
						};
						
						// Get new incoming message from remote client
						let message = match message {
							Ok(Text(x)) => x,
							Ok(_) => {
								debug!("C (from {}): (Unhandled message type)", address);
								continue 'message_loop
							},
							Err(ConnectionClosed) => {
								debug!("C (from {}): (Connection closed)", address);
								break 'message_loop
							}
							Err(error) => {
								warn!("C (from {}): (Unable to receive message due to {})", address, error);
								continue 'message_loop
							}
						};
						
						// Decode and execute commands
						const GOT_DATA: &str = "GOT_DATA ";
						if message.eq("GOT_CAM") {
							info!("C (from {}): GOT_CAM", address);
							
							// Finish handshake
							info!("S (to   {}): OK_CAM", address);
							if let Err(error) = ws_stream.send(Text("OK_CAM".to_owned())).await {
								error!("Unable to send message due to {}", error);
								break 'message_loop
							}
							is_ready = true;
							
							// Ask any previous TCPs to disconnect
							if let Err(error) = disconnect_sender.send(()) {
								warn!("Unable to broadcast TCP disconnect due to {}", error);
							}
							
							// Resubscribe after the send so we don't get our own message
							disconnect_receiver = disconnect_receiver.resubscribe();
						}
						else if message.starts_with(GOT_DATA) {
							debug!("C (from {}): {}...", address, &message[..min(message.len(), 16)]);
							trace!("C (from {}): {}", address, message);
							let vp8_data = message[GOT_DATA.len()..].to_owned();
							
							// If not ready yet (other TCPs are connected), don't use the data
							if !is_ready {
								warn!("Discarding data from client that was sent before GOT_CAM.");
								continue 'message_loop;
							}
							
							// Decode base64
							let decoded = match STANDARD.decode(&vp8_data) {
								Ok(x) => x,
								Err(error) => {
									warn!("Unable to decode base64 chunk due to {}", error);
									continue 'message_loop
								}
							};
							
							// Send data over to decoder
							if let Err(error) = decoder_sender.send(decoded).await {
								warn!("Unable to send decoded base64 chunk to video decoder due to {}", error);
								continue 'message_loop;
							}
						}
						else {
							warn!("C (from {}): (Invalid command)", address);
							continue 'message_loop
						}
					},
					disconnect_signal = disconnect_receiver.recv() => {
						if let Err(error) = disconnect_signal {
							warn!("Unable to get disconnect broadcasts due to {}, disconnecting just in case", error);
						}
						
						trace!("Got disconnect signal! Bye TCP.");
						break 'message_loop
					}
				}
			}
			info!("Connection with {} closed", address);
		});
	}
}
