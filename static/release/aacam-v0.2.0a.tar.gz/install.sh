# Copyright 2023 Lim Ding Wen
#
# This file is part of Anything Also Cam.
#
# Anything Also Cam is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
#
# Anything Also Cam is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License along with Anything Also Cam. If not, see <https://www.gnu.org/licenses/>.

#!/bin/sh

sudo modprobe v4l2loopback
sudo v4l2loopback-ctl add -n "Anything Also Cam" | sudo tee /etc/aacam/video
sudo v4l2loopback-ctl set-caps `cat /etc/aacam/video` "YU12:640x480@30"
