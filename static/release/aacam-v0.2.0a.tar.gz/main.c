// Copyright 2023 Lim Ding Wen
//
// This file is part of Anything Also Cam.
//
// Anything Also Cam is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
//
// Anything Also Cam is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License along with Anything Also Cam. If not, see <https://www.gnu.org/licenses/>.

#include "gui.h"
#include "vcam.h"
#include "globals.h"

#include <sys/socket.h>
#include <unistd.h>
#include <openssl/pem.h>
#include <openssl/sha.h>
#include <stdint.h>
#include <base64.h>
#include <sha1.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <stdlib.h>
#include <vpx/vpx_decoder.h>
#include <vpx/vp8dx.h>
#include <string.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <sys/mman.h>
#include <fcntl.h>

// Server config
// TODO: Make PORT configurable
#define PORT 4546
#define PORT_STR "4546"
#ifndef TLS_CERT
#define TLS_CERT "cert/cert.pem"
#endif // TLS_CERT
#ifndef TLS_KEY
#define TLS_KEY "cert/key.pem"
#endif // TLS_KEY
#ifndef TLS_FALLBACK
#define TLS_FALLBACK "/tmp/aacam"
#endif // TLS_FALLBACK

// File config
#ifndef SENDERHTML
#define SENDERHTML "sender/webpage.html"
#endif // SENDERHTML

// Logger globals
unsigned char logdbg = 0;

// VPX globals
vpx_codec_ctx_t vpx_ctx;

// Found IP/URL globals
struct sockaddr_in ip;
char url_str[30 /* 8(aacam://) + 3×4+3(255.255.255.255) + 6(:65535) + 1(\0) */];

// WebSocket globals
int ws_conn_active = -1;
pthread_mutex_t ws_conn_active_mut;
unsigned char ws_conn_active_mut_avail = 0;
SSL_CTX *ssl_ctx;

// HTML globals
unsigned char *senderhtml = (unsigned char *) "Unable to load HTML page, please check logs";
unsigned short senderhtml_len = sizeof senderhtml;

struct ws_onconnect_args {
	int ws_conn;
	SSL *ssl_conn;
};

void *ws_onconnect(void *args) {
	int err;
	vpx_codec_err_t err_vpx;
	int ws_conn = ((struct ws_onconnect_args *) args)->ws_conn;
    SSL *ssl_conn = ((struct ws_onconnect_args *) args)->ssl_conn;
	unsigned char tcp_buf[65536];
	DEBUG("New connection\n");

	// Get client handshake
	// FIXME: Does not work if entire HTTP request is not ready on connect
	ssize_t tcp_buf_read = SSL_read(ssl_conn, &tcp_buf, sizeof tcp_buf - 1);
	if (tcp_buf_read == -1) {
		ERROR("Unable to read HTTP request. Please report this to the developers\n");
		goto ws_end;
	}
	tcp_buf[tcp_buf_read] = 0;
	if (tcp_buf_read < 4 || memcmp(tcp_buf + tcp_buf_read - 4, "\r\n\r\n", 4) != 0) {
		ERROR("HTTP request did not end with empty line. Please report this to the developers\n");
		goto ws_end;
	}

	// Check if the client is requesting for HTML or an upgrade to a WS connection
	unsigned char *ws_upgrade_ptr = (unsigned char *) strstr((char *) tcp_buf, "Connection: Upgrade\r\n");
    if (!ws_upgrade_ptr) {
        // Client is likely requesting HTML
        DEBUG("Request headers:\n%s", tcp_buf);
        char *head = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Length: ";
        unsigned char contentsize[6 /* 65535 + NUL */];
        sprintf((char *) contentsize, "%u", senderhtml_len);
        SSL_write(ssl_conn, head, sizeof head - 1 /* Remove NUL */);
        SSL_write(ssl_conn, contentsize, strlen((char *) contentsize));
        SSL_write(ssl_conn, "\r\n\r\n", 4);
        SSL_write(ssl_conn, senderhtml, senderhtml_len /* Does lseek include NUL? Anyway, doesn't matter */);
    }
    else {
        // Client is likely requesting WS
        // Find WS key
        unsigned char ws_key_buf[60 /* 24 (in WS spec) + 36 (258EAFA5-E914-47DA-95CA-C5AB0DC85B11) */];
        unsigned char *ws_key_ptr = (unsigned char *) strstr((char *) tcp_buf, "Sec-WebSocket-Key: ");
        if (ws_key_ptr == 0 || (((unsigned short) (ws_key_ptr - tcp_buf)) + 43 /* 19 (Sec...Key) + 24 (in WS spec) */) >= sizeof tcp_buf - 1) {
            ERROR("Unable to find key. Please report this to the developers\n");
            goto ws_end;
        }
        memcpy(ws_key_buf, ws_key_ptr + 19, 24);
        ws_key_buf[24] = 0;
        DEBUG("Client handshake:\n%sKey found: %s\n", tcp_buf, ws_key_buf);

        // Calculate WS key
        memcpy(ws_key_buf + 24, "258EAFA5-E914-47DA-95CA-C5AB0DC85B11", 36);
        SHA1Context sha_ctx;
        err = SHA1Reset(&sha_ctx);
        if (err != shaSuccess) {
            ERROR("Unable to init SHA due to error %d. Please report this to the developers\n", err);
            goto ws_end;
        }
        err = SHA1Input(&sha_ctx, ws_key_buf, 60 /* 36 (magic key) + 24 (client key) */);
        if (err != shaSuccess) {
            ERROR("Unable to calculate SHA due to error %d. Please report this to the developers\n", err);
            goto ws_end;
        }
        unsigned char ws_sha1_buf[SHA1HashSize];
        err = SHA1Result(&sha_ctx, ws_sha1_buf);
        if (err != shaSuccess) {
            ERROR("Unable to get SHA result due to error %d. Please report this to the developers\n", err);
            goto ws_end;
        }
        size_t ws_accept_buf_len;
        unsigned char *ws_accept_buf = base64_encode(ws_sha1_buf, SHA1HashSize, &ws_accept_buf_len);
        if (!ws_accept_buf) {
            ERROR("Unable to encode base64 for accept token. Please report this to the developers\n");
            goto ws_end;
        }

        // Send server handshake
        unsigned char reply[] = "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ";
        DEBUG("Server handshake:\n%s%s\n", reply, ws_accept_buf);
        // -1 to get rid of the NUl term
        if (SSL_write(ssl_conn, reply, sizeof reply - 1) == -1) {
            perror(0);
            ERROR("Unable to write accept HTTP header. Please report this to the developers\n");
            goto ws_end;
        }
        if (SSL_write(ssl_conn, (char *) ws_accept_buf, ws_accept_buf_len - 1) == -1) {
            perror(0);
            ERROR("Unable to write accept HTTP accept token. Please report this to the developers\n");
            goto ws_end;
        }
        free(ws_accept_buf);
        if (SSL_write(ssl_conn, "\r\n\r\n", 4) == -1) {
            perror(0);
            ERROR("Unable to write accept HTTP end line. Please report this to the developers\n");
            goto ws_end;
        }

        // Check websocket responses
        while (1) {
            // Read WS header
            if (SSL_read(ssl_conn, tcp_buf, 2) < 2) {
                ERROR("Header was cut off. Please report this to the developers\n");
                goto ws_end;
            }
            if ((tcp_buf[0] & 0x80) == 0) {
                ERROR("Fragmentation not supported. Please report this to the developers\n");
                goto ws_end;
            }
            if ((tcp_buf[1] & 0x80) == 0) {
                ERROR("Message not masked. Please report this to the developers\n");
                goto ws_end;
            }
            unsigned char ws_opcode = tcp_buf[0] & 0x0F;
            unsigned short ws_len = tcp_buf[1] & 0x7F;
            if (ws_len == 126) {
                if (SSL_read(ssl_conn, tcp_buf, 2) < 2) {
                    ERROR("Header was cut off. Please report this to the developers\n");
                    goto ws_end;
                }
                ws_len = ((unsigned short) tcp_buf[0] << 8) | tcp_buf[1];
            }
            else if (ws_len == 127) {
                ERROR("Payload sizes > 65536 not supported. Please report this to the developers\n");
                goto ws_end;
            }
            unsigned char ws_mask[4];
            if (SSL_read(ssl_conn, ws_mask, 4) < 4) {
                ERROR("Header was cut off. Please report this to the developers\n");
                goto ws_end;
            }

            // Read payload
            // ws_len is max 65536, so if ws_len_read is accurate, this should be safe
            unsigned short ws_len_left = ws_len;
            while (ws_len_left > 0) {
                unsigned short ws_len_read = SSL_read(ssl_conn, tcp_buf + (ws_len - ws_len_left), ws_len_left);
                if (ws_len_read == -1) {
                    perror(0);
                    ERROR("Error reading payload. Please report this to the developers\n");
                    goto ws_end;
                }
                ws_len_left -= ws_len_read;
            }

            // Apply mask
            for (int i = 0; i < ws_len; i++) {
                tcp_buf[i] ^= ws_mask[i % 4];
            }

            // Handle payload
            if (ws_opcode == 0x01 || ws_opcode == 0x02) {
                // Handle data
                if (memcmp((char *) tcp_buf, "GOT_CAM", 7) == 0) {
                    DEBUG("Received: GOT_CAM\n");

                    // Make current connection the only one allowed to handle data
                    unsigned char locked = 0;
                    if (ws_conn_active_mut_avail) {
                        err = pthread_mutex_lock(&ws_conn_active_mut);
                        if (err == 0) {
                            locked = 1;
                        }
                        else {
                            WARN("Unable to acquire active connection lock due to error %d\n", err);
                        }
                    }
                    ws_conn_active = ws_conn;
                    if (ws_conn_active_mut_avail && locked) {
                        err = pthread_mutex_unlock(&ws_conn_active_mut);
                        if (err != 0) {
                            WARN("Unable to release active connection lock due to error %d\n", err);
                        }
                    }

                    // Send OK_CAM
                    unsigned char reply[] = {0b10000001, 6, 'O', 'K', '_', 'C', 'A', 'M'};
                    if (SSL_write(ssl_conn, reply, sizeof reply) == -1) {
                        perror(0);
                        WARN("Unable to send OK_CAM. Sender may or may not be okay with this\n");
                    }
                    DEBUG("Sent: OK_CAM\n");
                    DEBUG("Active connection is now %d\n", ws_conn_active);
                }
                else if (memcmp((char *) tcp_buf, "GOT_DATA ", 9) == 0) {
                    TRACE("Received: GOT_DATA (Binary data)\n");

                    // Check if we are the active connection
                    unsigned char locked = 0;
                    if (ws_conn_active_mut_avail) {
                        err = pthread_mutex_lock(&ws_conn_active_mut);
                        if (err == 0) {
                            locked = 1;
                        }
                        else {
                            WARN("Unable to acquire active connection lock due to error %d\n", err);
                        }
                    }
                    unsigned char allow = (ws_conn_active == ws_conn);
                    if (ws_conn_active_mut_avail && locked) {
                        err = pthread_mutex_unlock(&ws_conn_active_mut);
                        if (err != 0) {
                            WARN("Unable to release active connection lock due to error %d\n", err);
                        }
                    }
                    if (!allow) {
                        DEBUG("Client tried to send data to inactive connection %d, disconnecting\n", ws_conn);
                        goto ws_end;
                    }

                    // Decode data
                    err_vpx = vpx_codec_decode(&vpx_ctx, tcp_buf + 9, ws_len - 9, 0, 33333 /* 30 FPS */);
                    if (err_vpx != VPX_CODEC_OK) {
                        WARN("Unable to decode VPX due to error %d\n", err_vpx);
                    }
                }
                else {
                    WARN("Invalid command. Please report this to the developers\n");
                }
            }
            else if (ws_opcode == 0x08) {
                // Client indicated the connection has closed
                goto ws_end;
            }
            else {
                WARN("Message type %x not handled\n", ws_opcode);
            }
        }
    }

	ws_end:
    err = SSL_shutdown(ssl_conn);
    if (err < 0) {
        WARN("Unable to shutdown SSL due to error %d\n", SSL_get_error(ssl_conn, err));
    }
    SSL_free(ssl_conn);
	if (close(ws_conn) == -1) {
		perror(0);
		WARN("Unable to close connection\n");
	}
    DEBUG("Closed connection\n");
	return 0;
}

void *ws_serve(void *args) {
	int err;

	// Init OpenSSL for TLS
    SSL_load_error_strings();
    SSL_library_init();
    OpenSSL_add_all_algorithms();
    ssl_ctx = SSL_CTX_new(TLS_server_method());
    if (SSL_CTX_use_certificate_file(ssl_ctx, TLS_CERT, SSL_FILETYPE_PEM) != 1) {
        WARN("Unable to use cert file due to error %s. Creating fallback cert and key\n", ERR_error_string(ERR_get_error(), 0));
        goto certfallback;
    }
    if (SSL_CTX_use_PrivateKey_file(ssl_ctx, TLS_KEY, SSL_FILETYPE_PEM) != 1) {
        WARN("Unable to use key file due to error %s. Creating fallback cert and key\n", ERR_error_string(ERR_get_error(), 0));
        goto certfallback;
    }

    // Cert fallback
    goto skip_certfallback;
    certfallback:
    DEBUG("Creating cert " TLS_FALLBACK "/cert.pem and " TLS_FALLBACK "/key.pem\n");
    err = system("mkdir -p " TLS_FALLBACK " && cd " TLS_FALLBACK " && openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -sha256 -days 3650 -nodes -subj \"/C=XX/ST=StateName/L=CityName/O=CompanyName/OU=CompanySectionName/CN=CommonNameOrHostname\"");
    if (err != 0) {
        ERROR("Unable to create fallback certs due to error %d. Please report this to the developers\n", err);
        goto err_ret_ssl;
    }
    if (SSL_CTX_use_certificate_file(ssl_ctx, TLS_FALLBACK "/cert.pem", SSL_FILETYPE_PEM) != 1) {
        ERROR("Unable to use fallback cert due to %s. Please report this to the developers\n", ERR_error_string(ERR_get_error(), 0));
        goto err_ret_ssl;
    }
    if (SSL_CTX_use_PrivateKey_file(ssl_ctx, TLS_FALLBACK "/key.pem", SSL_FILETYPE_PEM) != 1) {
        ERROR("Unable to use fallback key to %s. Please report this to the developers\n", ERR_error_string(ERR_get_error(), 0));
        goto err_ret_ssl;
    }
    skip_certfallback:

	// Start server
	int ws_socket = socket(AF_INET, SOCK_STREAM, 6 /* TCP */);
	if (ws_socket == -1) {
		perror(0);
		ERROR("Unable to allocate socket. Please report this to the developers\n");
		goto err_ret_ssl;
	}
	int should_socket_be_reused = 1;
	if (setsockopt(ws_socket, SOL_SOCKET, SO_REUSEADDR, &should_socket_be_reused, sizeof should_socket_be_reused) == -1) {
		perror(0);
		ERROR("Unable to set socket options. Please report this to the developers\n");
		goto err_ret_ws;
	}
	if (bind(ws_socket, (struct sockaddr *) &ip, sizeof ip) == -1) {
		perror(0);
		ERROR("Unable to bind to socket %s. Is the program already running?\n", url_str);
		goto err_ret_ws;
	}
	if (listen(ws_socket, 2) == -1) {
		perror(0);
		ERROR("Unable to listen to socket. Please report this to the developers\n");
		goto err_ret_ws;
	}
	// LEAKS: ws_conn_active_mut
	err = pthread_mutex_init(&ws_conn_active_mut, 0);
	if (err == 0) {
		ws_conn_active_mut_avail = 1;
	}
	else {
		WARN("Unable to create active connection mutex. Falling back to no mutex\n");
	}
	INFO("Serving on %s\n", url_str);

	// Listen to new connections
	struct ws_onconnect_args ws_args;
	while (1) {
        // Accept connection
		int ws_conn = accept(ws_socket, 0, 0);
		if (ws_conn == -1) {
			perror(0);
			ERROR("Unable to accept connection. Please report this to the developers\n");
			continue;
		}

		// Create SSL for this connection
		SSL *ssl_conn = SSL_new(ssl_ctx);
		if (!ssl_conn) {
			ERROR("Unable to create SSL due to %s. Please report this to the developers\n", ERR_error_string(ERR_get_error(), 0));
			goto err_cont_ws;
        }
        if (!SSL_set_fd(ssl_conn, ws_conn)) {
            ERROR("Unable to bind SSL to socket due to %s. Please report this to the developers\n", ERR_error_string(ERR_get_error(), 0));
			goto err_cont_ssl;
        }
        err = SSL_accept(ssl_conn);
		if (err != 1) {
            err = SSL_get_error(ssl_conn, err);
            if (err == SSL_ERROR_SSL) {
                WARN("Unable to accept SSL due to error %s. If it says \"certificate unknown\", then you don't need to do anything; it's just the browser complaining. If it says \"http request\", then you should connect via HTTPS instead of HTTP. If it's another error, report this to the developers\n", ERR_error_string(ERR_get_error(), 0));
            }
            else {
                ERROR("Unable to accept SSL due to error %d. Please report this to the developers\n", err);
            }
            goto err_cont_ssl;
		}
		else {
            TRACE("SSL success\n");
		}

		TRACE("Creating WS thread\n");
		// Create thread to handle connection
		// (SSL and WS resources are now owned by thread)
		pthread_t ws_conn_thread;
		ws_args.ws_conn = ws_conn;
        ws_args.ssl_conn = ssl_conn;
		err = pthread_create(&ws_conn_thread, 0, ws_onconnect, &ws_args);
		if (err == 0) {
			err = pthread_detach(ws_conn_thread);
			if (err != 0) {
				WARN("Unable to detach thread for connection\n");
			}
		}
		else {
			ERROR("Unable to create thread for connection\n");
		}

        continue;
		// Error handling
		err_cont_ssl:
		// No need for SSL shutdown here, because as soon as SSL accept succeeds (and we shouldn't shutdown if it fails), it gets handed off to ws_thread. Not our problem anymore!
        SSL_free(ssl_conn);
        err_cont_ws:
		if (close(ws_conn) == -1) {
            perror(0);
            WARN("Unable to close connection\n");
        }
        TRACE("Did WS accept error handling\n");
        continue;
	}

	// Error handling
    err_ret_ws:
    if (close(ws_socket) == -1) {
        perror(0);
        WARN("Unable to close WS server socket\n");
    }
    err_ret_ssl:
	SSL_CTX_free(ssl_ctx);
    ERROR("WS server is shutting down\n");
	return 0;
}

int main(int argc, char **argv) {
	int err;
	vpx_codec_err_t err_vpx;

	// Check command line arguments
	for (unsigned char i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--debug") == 0) {
            logdbg = 1;
        }
	}

	// Get current IPv4
	struct ifaddrs *addresses;
	struct ifaddrs *original_addresses;
	unsigned char ip_detected = 0;
	if (getifaddrs(&addresses) == -1) {
		perror(0);
		WARN("Unable to find network interfaces. Using fallback\n");
		goto noaddr;
	}
	original_addresses = addresses;
	for (; addresses; addresses = addresses->ifa_next) {
		// Check if is IPv4
		if (addresses->ifa_addr->sa_family != AF_INET) {
			continue;
		}

		// Check if it is loopback (might be an issue on big-endian devices)
		ip = *((struct sockaddr_in *) addresses->ifa_addr);
		if (ip.sin_addr.s_addr == 0x0100007F) {
			continue;
		}

		// Done!
		ip_detected = 1;
		break;
	}
	freeifaddrs(original_addresses);
	if (!ip_detected) {
		WARN("Unable to find local IPv4 non-loopback address. Using fallback\n");
		goto noaddr;
	}

	// Fallback address
	goto skip_noaddr;
	noaddr:
	ip.sin_family = AF_INET;
	ip.sin_addr.s_addr = INADDR_ANY;
    ERROR("Using IP fallback. IP will show up as 0.0.0.0, and thus the QR code will likely not work, please find IP manually and connect to HTTPS via that, then enter it in manually\n");
	skip_noaddr:

	// Set port
	ip.sin_port = htons(PORT);

	// Get current URL
	char *ip_string = inet_ntoa(ip.sin_addr);
	if (sprintf(url_str, "aacam://%s:%d", ip_string, PORT) < 0) {
		ERROR("Unable to convert IPv4 address to address. QR code will not work, please find IP manually and connect to HTTPS via that, then enter it in manually\n");
		strcpy(url_str, "aacam://0.0.0.0:" PORT_STR);
	}

	// Load HTML
	int senderhtml_fd = open(SENDERHTML, O_RDONLY);
	if (senderhtml_fd == -1) {
        perror(0);
        ERROR("Unable to load sender.html. Please check if " SENDERHTML " exists, relative to the working directory\n");
        goto skip_senderhtml;
	}
    senderhtml_len = lseek(senderhtml_fd, 0, SEEK_END);
    if (senderhtml_len == -1) {
        perror(0);
        ERROR("Unable to check sender.html's size. Please report this to the developers\n");
        goto skip_senderhtml;
    }
	unsigned char *senderhtml_tmp = mmap(0, senderhtml_len, PROT_READ | PROT_WRITE, MAP_PRIVATE, senderhtml_fd, 0);
    if (senderhtml_tmp == MAP_FAILED) {
        perror(0);
        ERROR("Unable to mmap sender.html. Please report this to the developers\n");
        goto skip_senderhtml;
    }
    senderhtml = senderhtml_tmp;
    if (close(senderhtml_fd) == -1) {
        perror(0);
        WARN("Unable to close sender.html\n");
    }

    // Inject IP address into HTML file
    unsigned char *senderhtml_inj = (unsigned char *) strstr((char *) senderhtml, (char *) "%255.255.255.255%");
    if (senderhtml_inj) {
        *senderhtml_inj = '"';
        unsigned char *senderhtml_injend = (unsigned char *) stpcpy((char *) senderhtml_inj + 1, ip_string);
        *(senderhtml_injend++) = '"';
        for (; senderhtml_injend < senderhtml_inj + 17 /* %255.255.255.255% */; senderhtml_injend++) {
            *senderhtml_injend = ' ';
        }
    }
    else {
        WARN("Unable to inject IP into HTML file, please enter %s manually\n", url_str);
    }
    TRACE("IP injected, HTML is now\n%s\n", senderhtml);

    // Sender HTML is already pointing to a fallback static string, so if fail, don't write to it
    skip_senderhtml:

	// Init VPX decoder
	err_vpx = vpx_codec_dec_init(&vpx_ctx, vpx_codec_vp8_dx(), 0, 0);
	if (err_vpx != VPX_CODEC_OK) {
		FATAL("Unable to init VPX decoder due to error %d. Please report this to the developers\n", err_vpx);
		exit(EXIT_NOVPX);
	}

	// Modules on separate threads to not disturb GUI, detach since it's not expected to end
	pthread_t ws_thread;
	err = pthread_create(&ws_thread, 0, ws_serve, 0);
	if (err == 0) {
		err = pthread_detach(ws_thread);
		if (err != 0) {
			WARN("Unable to detach WS server thread due to error %d\n", err);
		}
	}
	else {
		ERROR("Unable to start WS server thread due to error %d. Please report this to the developers\n", err);
	}
	pthread_t vc_thread;
	err = pthread_create(&vc_thread, 0, vc_run, 0);
	if (err == 0) {
		err = pthread_detach(vc_thread);
		if (err != 0) {
			WARN("Unable to detach vcam thread due to error %d\n", err);
		}
	}
	else {
		ERROR("Unable to start vcam thread due to error %d. Please report this to the developers\n", err);
	}

	// Exit when GUI is closed
	rungui();
	return EXIT_OK;
}
