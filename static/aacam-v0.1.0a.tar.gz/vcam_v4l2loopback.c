// Copyright 2023 Lim Ding Wen
//
// This file is part of Anything Also Cam.
//
// Anything Also Cam is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
//
// Anything Also Cam is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License along with Anything Also Cam. If not, see <https://www.gnu.org/licenses/>.

#include "vcam.h"
#include "logger.h"
#include "decoder.h"
#include "globals.h"

#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <vpx/vpx_decoder.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
#include <string.h>

#ifndef DEV_CFG
#define DEV_CFG "/etc/aacam/video"
#endif
#define DEV_CFG_MAXLEN 32

extern vpx_image_t *vpx_img;
extern int vpx_img_id;
int vpx_img_curid_vc;

void *vc_run(void *args) {
	// Open device config
	int dev_cfg = open(DEV_CFG, O_RDONLY);
	if (dev_cfg == -1) {
		perror(0);
		ERROR("Unable to open device config at " DEV_CFG ". Try running install.sh or reinstalling from your package manager\n");
		return 0;
	}
	unsigned char dev_cfg_buf[DEV_CFG_MAXLEN];
	ssize_t dev_cfg_len = read(dev_cfg, dev_cfg_buf, DEV_CFG_MAXLEN);
	if (dev_cfg_len == -1) {
		perror(0);
		ERROR("Unable to read device config at " DEV_CFG ". Try running install.sh or reinstalling from your package manager\n");
		if (close(dev_cfg) == -1) {
			perror(0);
			WARN("Unable to close device config file at " DEV_CFG "\n");
		}
		return 0;
	}
	// Replace ending newline with NUL
	dev_cfg_buf[dev_cfg_len - 1] = 0;
	if (close(dev_cfg) == -1) {
		perror(0);
		WARN("Unable to close device config file at " DEV_CFG "\n");
	}
	
	// Open device
	// LEAKS: dev
	int dev = open((char *) dev_cfg_buf, O_RDWR);
	if (dev == -1) {
		perror(0);
		ERROR("Unable to open video device at %s. Try running install.sh or reinstalling from your package manager\n", dev_cfg_buf);
		return 0;
	}
	DEBUG("Running vcam using v4l2loopback on %s\n", dev_cfg_buf);
	
	unsigned char frame[460800 /* 640 * 480 (Y) + (640 * 480 / 4) * 2 (U and V)*/];
	while (1) {
		// FIXME: Likely conflicts with GUI's vpx_getimg() which causes tears (likely due to threading)
		//vpx_getimg();
		if (!vpx_img || vpx_img_curid_vc == vpx_img_id) {
			usleep(33333 /* 30 FPS */);
			continue;
		}
		vpx_img_curid_vc = vpx_img_id;
		TRACE("Detected new frame, sending to vcam\n");
		
		// Convert to 640x480 frame
		unsigned short rs_y = vpx_img->stride[VPX_PLANE_Y];
		unsigned short rs_uv = vpx_img->stride[VPX_PLANE_U];
		if (vpx_img->d_w != 640 || vpx_img->d_h != 480) {
			// TODO: Add dynamic resolution support, needs knowledge of v4l2loopback set-caps
			ERROR("Video not in 640x480. Please report this to the developers, or use a client that outputs only 640x480 frames\n");
			continue;
		}
		for (unsigned short y = 0; y < 480; y++) {
			memcpy(frame + y * 640, vpx_img->planes[VPX_PLANE_Y] + y * rs_y, 640);
		}
		for (unsigned short y = 0; y < 240; y++) {
			memcpy(frame + 640 * 480 + y * 320, vpx_img->planes[VPX_PLANE_U] + y * rs_uv, 320);
		}
		for (unsigned short y = 0; y < 240; y++) {
			memcpy(frame + 640 * 480 + 640 * 480 / 4 + y * 320, vpx_img->planes[VPX_PLANE_V] + y * rs_uv, 320);
		}
		if (write(dev, frame, 460800) == -1) {
			perror(0);
			ERROR("Unable to write frame to vcam. Please report this to the developers\n");
		}
	}	
}
