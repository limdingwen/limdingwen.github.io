// Copyright 2023 Lim Ding Wen
//
// This file is part of Anything Also Cam.
//
// Anything Also Cam is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
//
// Anything Also Cam is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License along with Anything Also Cam. If not, see <https://www.gnu.org/licenses/>.

#include "gui.h"
#include "globals.h"
#include "decoder.h"

#include <gtk/gtk.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <vpx/vpx_decoder.h>
#include <math.h>

#define BORDER_WIDTH 10
#define LAYOUT_SPACING 10
#define QR_SIZE 350
#define WEBAPP_URL "http://limdingwen.me/static/aacam_scanner.html"
#ifndef NOCONN_IMG_PATH
#define NOCONN_IMG_PATH "noconn.png"
#endif

extern struct sockaddr_in ip;
extern char url_str[30 /* Copied from main.c */];
extern vpx_image_t *vpx_img;
extern int vpx_img_id;
GtkWidget *outstream_img;
unsigned short outstream_curw = 0;
unsigned short outstream_curh = 0;
unsigned char *outstream_pix = 0;
GdkPixbuf *outstream_pixbuf = 0;
int vpx_img_curid_gui;

// From mystical at https://codereview.stackexchange.com/a/6503/105904 under CC-BY-SA 3.0
unsigned char clamp(int n){
    int a = 255;
    a -= n;
    a >>= 31;
    a |= n;
    n >>= 31;
    n = ~n;
    n &= a;
    return n;
}

void activate(GtkApplication *app, gpointer user_data) {
	// Create window
	GtkWidget *window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(window), "Anywhere Also Cam");
    gtk_container_set_border_width(GTK_CONTAINER(window), BORDER_WIDTH);
    
	// Create vertical layout box for all GUI elements
	GtkWidget *layout = gtk_box_new(GTK_ORIENTATION_VERTICAL, LAYOUT_SPACING);
	gtk_container_add(GTK_CONTAINER(window), layout);

	// Add connection instructions
	char instruction_str_fmt[] = "Step 1: On your camera device, go to <b>" WEBAPP_URL "</b>\nStep 2: Make sure the sender and the receiver are on the same network\nStep 3: On the web app, enter <b>%s</b>\nStep 4: You can now choose <b>Anything Also Cam</b> in any app that uses cameras";
	char instruction_str[sizeof instruction_str_fmt + sizeof url_str - 1 /* 2 NULs, we only need 1 */];
	sprintf(instruction_str, instruction_str_fmt, url_str);
	GtkWidget *instruction_lbl = gtk_label_new("");
	gtk_label_set_markup(GTK_LABEL(instruction_lbl), instruction_str);
	gtk_box_pack_start(GTK_BOX(layout), instruction_lbl, 0, 0, 0);
	
	// Add streaming output
	outstream_img = gtk_image_new_from_file(NOCONN_IMG_PATH);
	gtk_box_pack_start(GTK_BOX(layout), outstream_img, 0, 0, 0);

	// Finish creating window
    gtk_widget_show_all(window);
}

gboolean onframe() {
	// Get decoded frame
	vpx_getimg();
	if (!vpx_img || vpx_img_curid_gui == vpx_img_id) {
		return 1;
	}
	vpx_img_curid_gui = vpx_img_id;
	TRACE("Detected new frame, showing\n");
	
	// Allocate new pix/pixbuf if needed
	unsigned short w = vpx_img->d_w;
	unsigned short h = vpx_img->d_h;
	if (w != outstream_curw || h != outstream_curh) {
		DEBUG("New resolution detected: %u x %u\n", w, h);
		outstream_curw = w;
		outstream_curh = h;
		outstream_pix = realloc(outstream_pix, w * h * 3);
		if (!outstream_pix) {
			ERROR("Unable to allocate memory for outstream_pix. Will try again next frame. Likely out of memory, close other programs on your system\n");
			return 1;
		}
		if (outstream_pixbuf) {
			g_object_unref(outstream_pixbuf);
		}
		outstream_pixbuf = gdk_pixbuf_new_from_data(outstream_pix, GDK_COLORSPACE_RGB, 0, 8, w, h, w * 3, 0, 0);
	}
	
	// Convert YUV to RGB, setting pixbuf on the way
	unsigned short y_rs = vpx_img->stride[VPX_PLANE_Y];
	unsigned short uv_rs = vpx_img->stride[VPX_PLANE_U];
	for (unsigned short pos_y = 0; pos_y < h; pos_y++) {
		for (unsigned short pos_x = 0; pos_x < w; pos_x++) {
			unsigned char y = vpx_img->planes[VPX_PLANE_Y][pos_y * y_rs + pos_x];
			unsigned int tmp_uv = (pos_y >> 1) * uv_rs + (pos_x >> 1);
			unsigned char u = vpx_img->planes[VPX_PLANE_U][tmp_uv];
			unsigned char v = vpx_img->planes[VPX_PLANE_V][tmp_uv];
			unsigned int base_i = (pos_y * w + pos_x) * 3;
			short c = y - 16;
			short d = u - 128;
			short e = v - 128;
			short r = (298 * c + 409 * e + 128) >> 8;
			short g = (298 * c - 100 * d - 208 * e + 128) >> 8;
			short b = (298 * c + 516 * d + 128) >> 8;
			outstream_pix[base_i] = clamp(r);
			outstream_pix[base_i + 1] = clamp(g);
			outstream_pix[base_i + 2] = clamp(b);
		}
	}
	
	// Set to img via pixbuf, if not already set
	// FIXME: Weird artifacts on the sides, likely due to resize
	gtk_image_set_from_pixbuf(GTK_IMAGE(outstream_img), outstream_pixbuf);
	
	return 1;
}

void rungui() {
	// Create and run GTK3 application
	// LEAKS: app
    GtkApplication *app = gtk_application_new("me.limdingwen.anywhere-also-cam", 0);
    g_signal_connect(app, "activate", G_CALLBACK(activate), 0);
    g_timeout_add(33 /* 30 FPS */, G_SOURCE_FUNC(onframe), 0);
    DEBUG("Running GTK3 GUI\n");
    g_application_run(G_APPLICATION(app), 0, 0);
}
