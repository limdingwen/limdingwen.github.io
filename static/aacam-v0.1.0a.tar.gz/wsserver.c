// Copyright 2023 Lim Ding Wen
//
// This file is part of Anything Also Cam.
//
// Anything Also Cam is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
//
// Anything Also Cam is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License along with Anything Also Cam. If not, see <https://www.gnu.org/licenses/>.

#include "wsserver.h"
#include "globals.h"
#include "logger.h"

#include <stdlib.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>
#include <openssl/pem.h>
#include <openssl/sha.h>
#include <stdint.h>
#include <vpx/vpx_decoder.h>
#include <base64.h>
#include <sha1.h>

int ws_conn_active = -1;
pthread_mutex_t ws_conn_active_mut;
unsigned char ws_conn_active_mut_avail = 0;
extern struct sockaddr_in ip;
extern char url_str[];
extern vpx_codec_ctx_t vpx_ctx;

struct ws_onconnect_args {
	int ws_conn;
};

void *ws_onconnect(void *args) {
	int err;
	vpx_codec_err_t err_vpx;
	int ws_conn = ((struct ws_onconnect_args *) args)->ws_conn;
	unsigned char tcp_buf[65536];
	INFO("New connection\n");
		
	// Get client handshake
	// FIXME: Does not work if entire HTTP request is not ready on connect
	ssize_t tcp_buf_read = read(ws_conn, &tcp_buf, sizeof tcp_buf - 1);
	if (tcp_buf_read == -1) {
		ERROR("Unable to read HTTP request. Please report this to the developers\n");
		goto ws_end;
	}
	tcp_buf[tcp_buf_read] = 0;
	if (tcp_buf_read < 4 || memcmp(tcp_buf + tcp_buf_read - 4, "\r\n\r\n", 4) != 0) {
		ERROR("HTTP request did not end with empty line. Please report this to the developers\n");
		goto ws_end;
	}
	
	// Find WS key
	unsigned char ws_key_buf[60 /* 24 (in WS spec) + 36 (258EAFA5-E914-47DA-95CA-C5AB0DC85B11) */];
	unsigned char *ws_key_ptr = (unsigned char *) strstr((char *) tcp_buf, "Sec-WebSocket-Key: ");
	if (ws_key_ptr == 0 || (((unsigned short) (ws_key_ptr - tcp_buf)) + 43 /* 19 (Sec...Key) + 24 (in WS spec) */) >= sizeof tcp_buf - 1) {
		ERROR("Unable to find key. Please report this to the developers\n");
		goto ws_end;
	}
	memcpy(ws_key_buf, ws_key_ptr + 19, 24);
	ws_key_buf[24] = 0;
	DEBUG("Client handshake:\n%sKey found: %s\n", tcp_buf, ws_key_buf);
	
	// Calculate WS key
	memcpy(ws_key_buf + 24, "258EAFA5-E914-47DA-95CA-C5AB0DC85B11", 36);
	SHA1Context sha_ctx;
	err = SHA1Reset(&sha_ctx);
	if (err != shaSuccess) {
		ERROR("Unable to init SHA due to error %d. Please report this to the developers\n", err);
		goto ws_end;
	}
	err = SHA1Input(&sha_ctx, ws_key_buf, 60 /* 36 (magic key) + 24 (client key) */);
	if (err != shaSuccess) {
		ERROR("Unable to calculate SHA due to error %d. Please report this to the developers\n", err);
		goto ws_end;
	}
	unsigned char ws_sha1_buf[SHA1HashSize];
	err = SHA1Result(&sha_ctx, ws_sha1_buf);
	if (err != shaSuccess) {
		ERROR("Unable to get SHA result due to error %d. Please report this to the developers\n", err);
		goto ws_end;
	}
	size_t ws_accept_buf_len;
	unsigned char *ws_accept_buf = base64_encode(ws_sha1_buf, SHA1HashSize, &ws_accept_buf_len);
	if (!ws_accept_buf) {
		ERROR("Unable to encode base64 for accept token. Please report this to the developers\n");
		goto ws_end;
	}
	
	// Send server handshake
	unsigned char reply[] = "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ";
	DEBUG("Server handshake:\n%s%s\n", reply, ws_accept_buf);
	// -1 to get rid of the NUl term
	if (write(ws_conn, reply, sizeof reply - 1) == -1) {
		perror(0);
		ERROR("Unable to write accept HTTP header. Please report this to the developers\n");
		goto ws_end;
	}
	if (write(ws_conn, (char *) ws_accept_buf, ws_accept_buf_len - 1) == -1) {
		perror(0);
		ERROR("Unable to write accept HTTP accept token. Please report this to the developers\n");
		goto ws_end;
	}
	free(ws_accept_buf);
	if (write(ws_conn, "\r\n\r\n", 4) == -1) {
		perror(0);
		ERROR("Unable to write accept HTTP end line. Please report this to the developers\n");
		goto ws_end;
	}
	
	// Check websocket responses
	while (1) {
		// Read WS header
		if (read(ws_conn, tcp_buf, 2) < 2) {
			ERROR("Header was cut off. Please report this to the developers\n");
			goto ws_end;
		}
		if ((tcp_buf[0] & 0x80) == 0) {
			ERROR("Fragmentation not supported. Please report this to the developers\n");
			goto ws_end;
		}
		if ((tcp_buf[1] & 0x80) == 0) {
			ERROR("Message not masked. Please report this to the developers\n");
			goto ws_end;
		}
		unsigned char ws_opcode = tcp_buf[0] & 0x0F;
		unsigned short ws_len = tcp_buf[1] & 0x7F;
		if (ws_len == 126) {
			if (read(ws_conn, tcp_buf, 2) < 2) {
				ERROR("Header was cut off. Please report this to the developers\n");
				goto ws_end;
			}
			ws_len = ((unsigned short) tcp_buf[0] << 8) | tcp_buf[1];
		}
		else if (ws_len == 127) {
			ERROR("Payload sizes > 65536 not supported. Please report this to the developers\n");
			goto ws_end;
		}
		unsigned char ws_mask[4];
		if (read(ws_conn, ws_mask, 4) < 4) {
			ERROR("Header was cut off. Please report this to the developers\n");
			goto ws_end;
		}
		
		// Read payload
		// ws_len is max 65536, so if ws_len_read is accurate, this should be safe
		unsigned short ws_len_left = ws_len;
		while (ws_len_left > 0) {
			unsigned short ws_len_read = read(ws_conn, tcp_buf + (ws_len - ws_len_left), ws_len_left);
			if (ws_len_read == -1) {
				perror(0);
				ERROR("Error reading payload. Please report this to the developers\n");
				goto ws_end;
			}
			ws_len_left -= ws_len_read;
		}
		
		// Apply mask
		for (int i = 0; i < ws_len; i++) {
			tcp_buf[i] ^= ws_mask[i % 4];
		}
		
		// Handle payload
		if (ws_opcode == 0x01 || ws_opcode == 0x02) {
			// Handle data
			if (memcmp((char *) tcp_buf, "GOT_CAM", 7) == 0) {
				DEBUG("Received: GOT_CAM\n");
				
				// Make current connection the only one allowed to handle data
				unsigned char locked = 0;
				if (ws_conn_active_mut_avail) {
					err = pthread_mutex_lock(&ws_conn_active_mut);
					if (err == 0) {
						locked = 1;
					}
					else {
						WARN("Unable to acquire active connection lock due to error %d\n", err);
					}
				}
				ws_conn_active = ws_conn;
				if (ws_conn_active_mut_avail && locked) {
					err = pthread_mutex_unlock(&ws_conn_active_mut);
					if (err != 0) {
						WARN("Unable to release active connection lock due to error %d\n", err);
					}
				}
				
				// Send OK_CAM
				unsigned char reply[] = {0b10000001, 6, 'O', 'K', '_', 'C', 'A', 'M'};
				if (write(ws_conn, reply, sizeof reply) == -1) {
					perror(0);
					WARN("Unable to send OK_CAM. Sender may or may not be okay with this\n");
				}
				DEBUG("Sent: OK_CAM\n");
				DEBUG("Active connection is now %d\n", ws_conn_active);
			}
			else if (memcmp((char *) tcp_buf, "GOT_DATA ", 9) == 0) {
				TRACE("Received: GOT_DATA (Binary data)\n");
				
				// Check if we are the active connection
				unsigned char locked = 0;
				if (ws_conn_active_mut_avail) {
					err = pthread_mutex_lock(&ws_conn_active_mut);
					if (err == 0) {
						locked = 1;
					}
					else {
						WARN("Unable to acquire active connection lock due to error %d\n", err);
					}
				}
				unsigned char allow = (ws_conn_active == ws_conn);
				if (ws_conn_active_mut_avail && locked) {
					err = pthread_mutex_unlock(&ws_conn_active_mut);
					if (err != 0) {
						WARN("Unable to release active connection lock due to error %d\n", err);
					}
				}
				if (!allow) {
					DEBUG("Client tried to send data to inactive connection %d, disconnecting\n", ws_conn);
					goto ws_end;
				}
				
				// Decode data
				err_vpx = vpx_codec_decode(&vpx_ctx, tcp_buf + 9, ws_len - 9, 0, 33333 /* 30 FPS */);
				if (err_vpx != VPX_CODEC_OK) {
					WARN("Unable to decode VPX due to error %d\n", err_vpx);
				}
			}
			else {
				WARN("Invalid command. Please report this to the developers\n");
			}
		}
		else if (ws_opcode == 0x08) {
			// Client indicated the connection has closed
			goto ws_end;
		}
		else {
			WARN("Message type %x not handled\n", ws_opcode);
		}
	}
	
	ws_end:
	INFO("Closed connection\n");
	if (close(ws_conn) == -1) {
		perror(0);
		WARN("Unable to close connection\n");
	}
	return 0;
}

void *ws_serve(void *args) {
	int err;
	
	// Start server
	int ws_socket = socket(AF_INET, SOCK_STREAM, 6 /* TCP */);
	if (ws_socket == -1) {
		perror(0);
		ERROR("Unable to allocate socket. Please report this to the developers\n");
		goto err_ret;
	}
	int should_socket_be_reused = 1;
	if (setsockopt(ws_socket, SOL_SOCKET, SO_REUSEADDR, &should_socket_be_reused, sizeof should_socket_be_reused) == -1) {
		perror(0);
		ERROR("Unable to set socket options. Please report this to the developers\n");
		goto err_ret;
	}
	if (bind(ws_socket, (struct sockaddr *) &ip, sizeof ip) == -1) {
		perror(0);
		ERROR("Unable to bind to socket %s. Is the program already running?\n", url_str);
		goto err_ret;
	}
	if (listen(ws_socket, 2) == -1) {
		perror(0);
		ERROR("Unable to listen to socket. Please report this to the developers\n");
		goto err_ret;
	}
	// LEAKS: ws_conn_active_mut
	err = pthread_mutex_init(&ws_conn_active_mut, 0);
	if (err == 0) {
		ws_conn_active_mut_avail = 1;
	}
	else {
		WARN("Unable to create active connection mutex. Falling back to no mutex\n");
	}
	INFO("Serving on %s\n", url_str);
	
	// Listen to new connections and make new threads for them
	struct ws_onconnect_args ws_args;
	while (1) {
		int ws_conn = accept(ws_socket, 0, 0);
		if (ws_conn == -1) {
			perror(0);
			ERROR("Unable to accept connection. Please report this to the developers\n");
			continue;
		}
		pthread_t ws_conn_thread;
		ws_args.ws_conn = ws_conn;
		err = pthread_create(&ws_conn_thread, 0, ws_onconnect, &ws_args);
		if (err == 0) {
			err = pthread_detach(ws_conn_thread);
			if (err != 0) {
				WARN("Unable to detach thread for connection\n");
			}
		}
		else {
			ERROR("Unable to create thread for connection\n");
		}
	}
	
	err_ret:
	ERROR("WS server is shutting down\n");
	if (close(ws_socket) == -1) {
		perror(0);
		WARN("Unable to close WS server socket\n");
	}
	return 0;
}
