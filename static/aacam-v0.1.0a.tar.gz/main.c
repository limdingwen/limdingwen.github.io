// Copyright 2023 Lim Ding Wen
//
// This file is part of Anything Also Cam.
//
// Anything Also Cam is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
//
// Anything Also Cam is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License along with Anything Also Cam. If not, see <https://www.gnu.org/licenses/>.

#include "gui.h"
#include "vcam.h"
#include "wsserver.h"
#include "globals.h"

#include <ifaddrs.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <stdlib.h>
#include <vpx/vpx_decoder.h>
#include <vpx/vp8dx.h>
#include <string.h>

#define PORT 4546
#define PORT_STR "4546"

vpx_codec_ctx_t vpx_ctx;
struct sockaddr_in ip;
char url_str[30 /* 8(aacam://) + 3×4+3(255.255.255.255) + 6(:65535) + 1(\0) */];

int main(int argc, char **argv) {
	int err;
	vpx_codec_err_t err_vpx;
	
	// Get current IPv4
	struct ifaddrs *addresses;
	struct ifaddrs *original_addresses;
	unsigned char ip_detected = 0;
	if (getifaddrs(&addresses) == -1) {
		perror(0);
		WARN("Unable to find network interfaces. Using fallback\n");
		goto noaddr;
	}
	original_addresses = addresses;
	for (; addresses; addresses = addresses->ifa_next) {
		// Check if is IPv4
		if (addresses->ifa_addr->sa_family != AF_INET) {
			continue;
		}
		
		// Check if it is loopback (might be an issue on big-endian devices)
		ip = *((struct sockaddr_in *) addresses->ifa_addr);
		if (ip.sin_addr.s_addr == 0x0100007F) {
			continue;
		}
		
		// Done!
		ip_detected = 1;
		break;
	}
	freeifaddrs(original_addresses);
	if (!ip_detected) {
		WARN("Unable to find local IPv4 non-loopback address. Using fallback\n");
		goto noaddr;
	}
	
	// Fallback address
	goto skipnoaddr;
	noaddr:
	ip.sin_family = AF_INET;
	ip.sin_addr.s_addr = INADDR_ANY;
	skipnoaddr:
	
	// Set port
	ip.sin_port = htons(PORT);
	
	// Get current URL
	char *ip_string = inet_ntoa(ip.sin_addr);
	if (sprintf(url_str, "aacam://%s:%d", ip_string, PORT) < 0) {
		ERROR("Unable to convert IPv4 address to address. QR code will not work, please find IP manually\n");
		strcpy(url_str, "aacam://0.0.0.0:" PORT_STR);
	}
	
	// Init VPX decoder
	err_vpx = vpx_codec_dec_init(&vpx_ctx, vpx_codec_vp8_dx(), 0, 0);
	if (err_vpx != VPX_CODEC_OK) {
		FATAL("Unable to init VPX decoder due to error %d. Please report this to the developers\n", err_vpx);
		exit(EXIT_NOVPX);
	}
	
	// Modules on separate threads to not disturb GUI, detach since it's not expected to end
	pthread_t ws_thread;
	err = pthread_create(&ws_thread, 0, ws_serve, 0);
	if (err == 0) {
		err = pthread_detach(ws_thread);
		if (err != 0) {
			WARN("Unable to detach WS server thread due to error %d\n", err);
		}
	}
	else {
		ERROR("Unable to start WS server thread due to error %d. Please report this to the developers\n", err);
	}
	pthread_t vc_thread;
	err = pthread_create(&vc_thread, 0, vc_run, 0);
	if (err == 0) {
		err = pthread_detach(vc_thread);
		if (err != 0) {
			WARN("Unable to detach vcam thread due to error %d\n", err);
		}
	}
	else {
		ERROR("Unable to start vcam thread due to error %d. Please report this to the developers\n", err);
	}
	
	// Exit when GUI is closed
	rungui();
	return EXIT_OK;
}
