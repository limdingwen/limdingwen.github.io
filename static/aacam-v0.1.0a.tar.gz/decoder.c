// Copyright 2023 Lim Ding Wen
//
// This file is part of Anything Also Cam.
//
// Anything Also Cam is free software: you can redistribute it and/or modify it under the terms of the GNU Affero General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
//
// Anything Also Cam is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License along with Anything Also Cam. If not, see <https://www.gnu.org/licenses/>.

#include "decoder.h"
#include "logger.h"

#include <vpx/vpx_decoder.h>
#include <stdlib.h>

extern vpx_codec_ctx_t vpx_ctx;
vpx_image_t *vpx_img = 0;
int vpx_img_id;

void vpx_getimg() {
	vpx_codec_iter_t iter = 0;
	vpx_image_t *img_tmp;
	unsigned char img_decoded = 0;
	while ((img_tmp = vpx_codec_get_frame(&vpx_ctx, &iter))) {
		vpx_img = img_tmp;
		img_decoded = 1;
	}
	if (!img_decoded) {
		return;
	}
	vpx_img_id = rand();
	TRACE("Frame decoded\n");
}
